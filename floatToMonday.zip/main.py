import lambda_main




if __name__ == '__main__':
    lambda_main.starFloatToMonday('','')















