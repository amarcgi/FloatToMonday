from .__version__ import __author__, __email__, __version__

from .client import MondayClient

__all__ = ['MondayClient']
